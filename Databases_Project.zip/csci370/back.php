<!DOCTYPE html>
<!-- Created by Sami Al-Qusus March 17, 2018 -->
<!-- modified April 15, 2018 -->
<!-- back.php for CSCI370 Project -->
        <footer class="fixed-bottom text-center">
           <small>Copyright &copy;2018 <b>ZAMZAM</b></small>
        </footer>
        </div>
    </body>
</html>

